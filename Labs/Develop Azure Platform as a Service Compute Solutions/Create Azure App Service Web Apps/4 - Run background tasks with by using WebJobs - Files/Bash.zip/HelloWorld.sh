#!/bin/bash

currentdate=`date +"%Y-%m-%d"`
currenttime=`date +"%T"`
echo "Hello World from Bash ! Today is ${currentdate} and it's ${currenttime} !";

#read -n1 -r -p "Press any key to continue..." key