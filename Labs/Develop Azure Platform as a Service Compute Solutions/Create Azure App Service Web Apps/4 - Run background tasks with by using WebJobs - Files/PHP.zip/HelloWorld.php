<?php
    print("Hello World from PHP ! Today is " . date("Y-m-d") . " and it's " . date("H:i:s") . " ! ");
?>